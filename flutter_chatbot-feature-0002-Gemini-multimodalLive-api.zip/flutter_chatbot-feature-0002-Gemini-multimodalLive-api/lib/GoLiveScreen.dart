import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter_sound/flutter_sound.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:vad/vad.dart';

class GoLiveScreen extends StatefulWidget {
  @override
  State<GoLiveScreen> createState() => _GoLiveScreenState();
}

class _GoLiveScreenState extends State<GoLiveScreen> {
  CameraController? camCtrl;
  FlutterSoundPlayer? player;
  FlutterSoundRecorder? recorder;
  WebSocketChannel? ws;
  final VAD vad = VAD();
  bool isStreaming = false;
  bool isPlaying = false;
  final pendingAudio = <Uint8List>[];
  StreamSubscription? wsSub;
  Timer? _frameTimer;

  @override
  void initState() {
    super.initState();
    // Do not auto-start, wait for user to press "Start Live"
  }

  Future<void> initAll() async {
    final cameras = await availableCameras();
    camCtrl = CameraController(cameras.first, ResolutionPreset.medium);
    await camCtrl!.initialize();
    setState(() {});

    player = FlutterSoundPlayer();
    await player!.openPlayer();

    recorder = FlutterSoundRecorder();
    await recorder!.openRecorder();

    ws = WebSocketChannel.connect(
      Uri.parse('wss://us-central1-aiplatform.googleapis.com/ws/google.cloud.aiplatform.v1beta1.LlmBidiService/BidiGenerateContent'),
    );
    wsSub = ws!.stream.listen(onMessage);

    startCameraLoop();
    monitorVAD();
  }

  // 2. Send video frames continuously
  void startCameraLoop() {
    _frameTimer = Timer.periodic(Duration(seconds: 4), (_) async {
      if (camCtrl != null && camCtrl!.value.isInitialized) {
        final img = await camCtrl!.takePicture();
        final bytes = await img.readAsBytes();
        ws?.sink.add(jsonEncode({
          'clientContent': {
            'image': base64Encode(bytes),
            'type': 'BidiGenerateContentRealtimeInput',
          }
        }));
      }
    });
  }

  // 3. Handle incoming server responses
  Future<void> onMessage(dynamic msg) async {
    final data = jsonDecode(msg);
    final serverEvent = data['serverContent'];

    // Check for interruption or function cancellation
    if (serverEvent['canceledFunctionCallIds'] != null) {
      // handle cancellation
      pendingAudio.clear();
      return;
    }

    final audioBase64 = serverEvent['audio'];
    if (audioBase64 != null) {
      final chunk = base64Decode(audioBase64);
      pendingAudio.add(chunk);
      // Only start playback if not already playing
      if (!isPlaying) {
        _playNext();
      }
      // If already playing, the chunk will be played after current finishes
    }
  }

  Future<void> _playNext() async {
    if (pendingAudio.isEmpty) {
      isPlaying = false;
      return;
    }
    isPlaying = true;
    final chunk = pendingAudio.removeAt(0);
    await player!.startPlayer(
      fromDataBuffer: chunk,
      whenFinished: () {
        isPlaying = false;
        _playNext();
      },
    );
  }

  // 4. Monitor VAD for user interruptions
  void monitorVAD() async {
    await recorder!.startRecorder(
      toStream: (data) {
        if (vad.process(data) > 0.8) {
          ws?.sink.add(jsonEncode({
            'clientContent': {'interrupt': true}
          }));
        }
      },
    );
  }

  Future<void> disposeAll() async {
    await _frameTimer?.cancel();
    await camCtrl?.dispose();
    await player?.closePlayer();
    await recorder?.closeRecorder();
    await wsSub?.cancel();
    await ws?.sink.close();
  }

  @override
  void dispose() {
    disposeAll();
    super.dispose();
  }

  Future<void> startLive() async {
    setState(() {
      isStreaming = true;
    });
    await initAll();
  }

  Future<void> stopLive() async {
    setState(() {
      isStreaming = false;
    });
    await disposeAll();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: Text('Go Live', style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.black,
      ),
      body: Stack(
        children: [
          if (camCtrl != null && camCtrl!.value.isInitialized)
            Positioned.fill(child: CameraPreview(camCtrl!)),
          Positioned(
            left: 0,
            right: 0,
            bottom: 30,
            child: SafeArea(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ElevatedButton.icon(
                    icon: Icon(isStreaming ? Icons.stop : Icons.videocam),
                    label: Text(isStreaming ? 'Stop Live' : 'Start Live'),
                    onPressed: isStreaming ? stopLive : startLive,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}