import 'dart:convert';
import 'package:http/http.dart';
import 'dart:io';

class ChatService {
  String key;
  ChatService(this.key);

  // Fetch relevant embeddings from Pinecone
  Future<List<Map<String, dynamic>>> fetchRelevantEmbeddings(
      String query
      ) async {
    try {
      // Generate embeddings for the query using OpenAI
      final embeddingResponse = await post(
        Uri.parse('https://api.openai.com/v1/embeddings'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $key',
        },
        body: jsonEncode({
          "model": "text-embedding-3-small",
          "input": query,
          "encoding_format": "float",
        }),
      );

      // Declare queryEmbedding here
      // dynamic queryEmbedding;

      if (embeddingResponse.statusCode == 200) {
        final embeddingData = jsonDecode(
          embeddingResponse.body,
        );
        if (embeddingData['data'] != null &&
            embeddingData['data'][0]['embedding'] != null &&
            embeddingData['data'].isNotEmpty) {
          final queryEmbedding = embeddingData['data'][0]['embedding'];
          print("if condition executed");
          // }
          print("fetchRelevantEmbeddings executed");

          // Query Pinecone for similar embeddings
          final pineconeResponse = await post(
            Uri.parse(
              'https://car-manual-zuan1hg.svc.aped-4627-b74a.pinecone.io/query',
            ),
            headers: {
              'Content-Type': 'application/json',
              'Api-Key':
              "pcsk_7Phkca_CQmZW46QRANoVRcvtij2bkaJKpxkN6vuUmZ72okfTLE8FVrM16q6AxFBULczxh7",
            },
            body: jsonEncode({
              "vector": queryEmbedding,
              "topK": 3, // Number of relevant embeddings to retrieve
              "includeMetadata": true,
            }),
          );

          if (pineconeResponse.statusCode == 200) {
            final pineconeData = jsonDecode(pineconeResponse.body);
            return List<Map<String, dynamic>>.from(pineconeData['matches']);
          } else {
            print('Failed to query Pinecone: ${pineconeResponse.statusCode}');
            print('Body: ${pineconeResponse.body}');
            return [];
          }
        } else {
          // Handle the case where embeddingData does not meet the conditions
          print('Embedding data is invalid or empty.');
          return [];
        }
      } else {
        print('Failed to generate query embeddings: ${embeddingResponse.statusCode}');
        print('Body: ${embeddingResponse.body}');
        return [];
      }
    } catch (e) {
      print('Exception during Pinecone query: $e');
      return [];
    }
  }

  askChatGPT(List<Map<String, Object>> ChatHistory, String context) async {
    List<Map<String, Object>> tempChatHistory = List.from(ChatHistory);
    tempChatHistory.add({"role": "system", "content": "Context:\n$context"});

    try {
      final response = await post(
        Uri.parse('https://api.openai.com/v1/chat/completions'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $key',
        },
        body: jsonEncode({
          "model": "gpt-4o",
          "messages": tempChatHistory,
          "max_tokens": 350,
        }),
      );

      if (response.statusCode == 200) {
        final jsonData = jsonDecode(response.body);
        return jsonData['choices'][0]['message']['content'];
      } else {
        print('Failed with status: ${response.statusCode}');
        print('Body: ${response.body}');
        return "There is an error!";
      }
    } catch (e) {
      print('Exception during HTTP call: $e');
      return "Network Error!";
    }
  }

  generateImages(String prompt) async {
    try {
      final response = await post(
        Uri.parse('https://api.openai.com/v1/images/generations'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $key',
        },
        body: jsonEncode({
          "model": "dall-e-3",
          "prompt": prompt,
          "quality": "standard", // or "hd" for higher quality
          "response_format": "url",
          "size": "1024x1024",
        }),
      );

      if (response.statusCode == 200) {
        final jsonData = jsonDecode(response.body);
        return jsonData['data'][0]['url'];
      } else {
        print('Failed with status: ${response.statusCode}');
        print('Body: ${response.body}');
        return "There is an error!";
      }
    } catch (e) {
      print('Exception during HTTP call: $e');
      return "Network Error!";
    }
  }
}
